import 'package:flutter/material.dart';

class MovieCommentView extends StatelessWidget {
  const MovieCommentView({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Container(height: 800, color: Colors.amber);
  }
}